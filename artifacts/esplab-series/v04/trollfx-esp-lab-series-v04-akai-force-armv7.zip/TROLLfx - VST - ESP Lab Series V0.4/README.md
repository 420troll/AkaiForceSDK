# TROLLfx ESP Lab Series V0.4

Four separately controlled stereo units run in a fixed serial order: A → B → C → D. Each unit can select Delay, Chorus, Flanger, Room, Hall, Plate, Modulated Reverb, VCF Distortion, EQ-Panner-DDL or Compressor, with its own mix, bypass and controls. The routing page shows each unit and its selected algorithm; the chain order cannot be changed.

The DSP uses TROLLfx's original allocation-free-per-block C++ processing engine, informed by the DP/4 Musician's Manual and local TeleBrain parameter tables. It is a native original-DSP design, not an ES5510 instruction emulator and not recovered Ensoniq factory microcode. The separate `TfxR` ES5510 NonLin Reverb V0.3 plugin remains installed independently.

## Force package

Build with the official Akai MPC Plugin Builder SDK. The SDK package includes ARMv7 hard-float and ARM64 binaries, TUI/Q-Link skin, installation notes and third-party notices. Install as a separate plugin folder. Do not remove the V0.3 ES5510 folder or its Issue #9 backup.
